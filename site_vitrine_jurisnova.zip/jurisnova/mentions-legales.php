<?php
$cfg = require __DIR__ . '/config.php';
$c = $cfg['cabinet'];
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mentions légales — <?= h($c['nom']) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
<style>
  .legal { max-width: 760px; margin: 0 auto; padding: clamp(4rem,8vw,6rem) clamp(1.2rem,5vw,3rem); }
  .legal h1 { font-size: clamp(2rem,5vw,3rem); color: var(--navy); margin-bottom: 2rem; }
  .legal h2 { font-size: 1.3rem; color: var(--navy); margin: 2.5rem 0 .6rem; }
  .legal p { color: #333; }
  .legal a.back { color: var(--gold); text-decoration: none; font-weight: 600; }
</style>
</head>
<body>
<header class="site-header">
  <a class="brand" href="index.php">
    <span class="brand__mark" aria-hidden="true">JN</span>
    <span class="brand__text">JurisNova</span>
  </a>
  <nav class="site-nav"><a href="index.php" class="nav-cta">Retour au site</a></nav>
</header>

<main class="legal">
  <h1>Mentions légales</h1>

  <h2>Éditeur du site</h2>
  <p><?= h($c['nom']) ?> — cabinet d'avocats, fondé en 2005 par Maître Richard Dupond.<br>
  <?= h($c['adresse']) ?>, <?= h($c['cp_ville']) ?>.<br>
  Téléphone : <?= h($c['telephone']) ?> — E-mail : <?= h($c['email']) ?></p>

  <h2>Directeur de la publication</h2>
  <p>Maître Richard Dupond.</p>

  <h2>Hébergement</h2>
  <p>Le site est hébergé sur l'infrastructure interne du cabinet (serveur Apache dédié),
  exploitée et maintenue dans le respect des exigences de sécurité applicables aux données
  couvertes par le secret professionnel.</p>

  <h2>Données personnelles</h2>
  <p>Les informations transmises via le formulaire de contact sont utilisées uniquement
  pour traiter votre demande. Conformément au Règlement général sur la protection des données
  (RGPD), vous disposez d'un droit d'accès, de rectification et de suppression des données
  vous concernant, exerçable à l'adresse <?= h($c['email']) ?>.</p>

  <h2>Propriété intellectuelle</h2>
  <p>L'ensemble des contenus présents sur ce site est la propriété du Cabinet JurisNova.
  Toute reproduction sans autorisation est interdite.</p>

  <p style="margin-top:2.5rem"><a class="back" href="index.php">&larr; Retour à l'accueil</a></p>
</main>
</body>
</html>
