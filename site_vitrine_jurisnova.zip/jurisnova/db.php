<?php
/**
 * db.php — Connexion à MariaDB (mysqli)
 *
 * Renvoie un objet mysqli connecté, ou null si la base est injoignable.
 * Le site vitrine doit rester consultable même si la BDD tombe (haute
 * disponibilité côté affichage) : on ne fait donc JAMAIS planter la page
 * publique sur une erreur de connexion, on log et on renvoie null.
 */

function jurisnova_db(): ?mysqli
{
    static $conn = null;
    static $tried = false;

    if ($tried) {
        return $conn;
    }
    $tried = true;

    $cfg = require __DIR__ . '/config.php';
    $db  = $cfg['db'];

    // On désactive les exceptions automatiques pour gérer l'erreur nous-mêmes.
    mysqli_report(MYSQLI_REPORT_OFF);

    $link = @mysqli_connect($db['host'], $db['user'], $db['pass'], $db['name'], $db['port']);

    if (!$link) {
        // Trace côté serveur (récupérée par les logs Apache/PHP), jamais affichée au visiteur.
        error_log('[JurisNova] Connexion MariaDB impossible : ' . mysqli_connect_error());
        return null;
    }

    mysqli_set_charset($link, 'utf8mb4');
    $conn = $link;
    return $conn;
}
