<?php
/**
 * config.php — Paramètres du site vitrine JurisNova
 *
 * Les valeurs ci-dessous correspondent à l'architecture décrite dans le rapport :
 *   - Serveur web Apache  : VLAN 20 (DMZ_Web)  -> 10.0.0.130
 *   - Serveur MariaDB     : VLAN 30 (DMZ_BDD)  -> 10.0.0.162
 *   - Base de données     : jurisnova_db
 *   - Compte applicatif   : user_web (droits SELECT + INSERT uniquement)
 *
 * IMPORTANT (production) : ne jamais committer le vrai mot de passe.
 * Remplacez la valeur ou utilisez une variable d'environnement :
 *   $value = getenv('DB_PASS') ?: 'MotsDePasseSecurise';
 */

return [
    'db' => [
        'host' => '10.0.0.162',
        'user' => 'user_web',
        'pass' => 'MotsDePasseSecurise',
        'name' => 'jurisnova_db',
        'port' => 3306,
    ],
    'cabinet' => [
        'nom'       => 'Cabinet JurisNova',
        'baseline'  => "L'expertise juridique alliée à l'innovation numérique.",
        'email'     => 'contact@jurisnova.fr',
        'telephone' => '+33 (0)1 53 00 00 00',
        // Adresse représentative dans le 8e arr. — à remplacer par l'adresse réelle du cabinet.
        'adresse'   => '24 avenue de Friedland',
        'cp_ville'  => '75008 Paris',
    ],
];
