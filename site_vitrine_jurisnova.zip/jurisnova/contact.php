<?php
/**
 * contact.php — Traitement du formulaire de contact
 * Enregistre le message dans MariaDB (table messages_contact) via une
 * requête préparée, puis redirige vers index.php#contact avec un statut.
 * Démontre concrètement le flux Apache (DMZ_Web) -> MariaDB (DMZ_BDD).
 */
require __DIR__ . '/db.php';

function redirect(string $statut): void
{
    header('Location: index.php?contact=' . urlencode($statut) . '#contact');
    exit;
}

// On n'accepte que les envois POST.
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    redirect('invalide');
}

// --- Récupération + nettoyage ---
$nom          = trim($_POST['nom'] ?? '');
$email        = trim($_POST['email'] ?? '');
$organisation = trim($_POST['organisation'] ?? '');
$sujet        = trim($_POST['sujet'] ?? '');
$message      = trim($_POST['message'] ?? '');

// --- Validation ---
$valide = $nom !== ''
    && $sujet !== ''
    && $message !== ''
    && filter_var($email, FILTER_VALIDATE_EMAIL)
    && mb_strlen($nom) <= 120
    && mb_strlen($email) <= 180
    && mb_strlen($organisation) <= 180
    && mb_strlen($sujet) <= 160
    && mb_strlen($message) <= 4000;

if (!$valide) {
    redirect('invalide');
}

$conn = jurisnova_db();
if (!$conn) {
    redirect('erreur');
}

// --- Insertion sécurisée (requête préparée) ---
$ip   = $_SERVER['REMOTE_ADDR'] ?? null;
$stmt = mysqli_prepare(
    $conn,
    'INSERT INTO messages_contact (nom, email, organisation, sujet, message, ip_source)
     VALUES (?, ?, ?, ?, ?, ?)'
);

if (!$stmt) {
    error_log('[JurisNova] Préparation INSERT échouée : ' . mysqli_error($conn));
    redirect('erreur');
}

$org = $organisation !== '' ? $organisation : null;
mysqli_stmt_bind_param($stmt, 'ssssss', $nom, $email, $org, $sujet, $message, $ip);

if (mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    redirect('ok');
}

error_log('[JurisNova] Exécution INSERT échouée : ' . mysqli_stmt_error($stmt));
mysqli_stmt_close($stmt);
redirect('erreur');
