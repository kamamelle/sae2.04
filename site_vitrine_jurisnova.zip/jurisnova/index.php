<?php
/**
 * index.php — Site vitrine du Cabinet JurisNova
 * Hébergé sur Apache (VLAN 20 / DMZ_Web), accessible publiquement.
 */
require __DIR__ . '/db.php';
$cfg     = require __DIR__ . '/config.php';
$cabinet = $cfg['cabinet'];

// --- Lecture des expertises en base (démonstration SELECT MariaDB) ---
$expertises = [];
$db_ok = false;
if ($conn = jurisnova_db()) {
    $db_ok = true;
    if ($res = mysqli_query($conn, "SELECT titre, resume FROM expertises ORDER BY position ASC")) {
        while ($row = mysqli_fetch_assoc($res)) {
            $expertises[] = $row;
        }
        mysqli_free_result($res);
    }
}
// Repli statique si la BDD est momentanément injoignable : le site reste consultable.
if (empty($expertises)) {
    $expertises = [
        ['titre' => 'Droit commercial & des affaires', 'resume' => 'Sécurisation de vos contrats stratégiques et de vos relations commerciales.'],
        ['titre' => 'Compliance & conformité',          'resume' => 'Programmes de conformité réglementaire et cartographie des risques.'],
        ['titre' => 'Droit des sociétés & gouvernance', 'resume' => 'Opérations sur le capital, fusions-acquisitions et gouvernance.'],
        ['titre' => 'Contentieux & arbitrage',          'resume' => 'Défense de vos intérêts devant les juridictions et en arbitrage.'],
    ];
}

// --- Message de retour du formulaire de contact ---
$flash = $_GET['contact'] ?? '';
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($cabinet['nom']) ?> — Avocats, droit commercial & compliance · Paris 8ᵉ</title>
<meta name="description" content="Cabinet JurisNova, avocats à Paris depuis 2005. Conseil et contentieux en droit commercial, compliance et droit des sociétés pour PME, start-ups et groupes.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>

<header class="site-header" id="haut">
  <a class="brand" href="#haut" aria-label="Cabinet JurisNova, accueil">
    <span class="brand__mark" aria-hidden="true">JN</span>
    <span class="brand__text">JurisNova</span>
  </a>
  <nav class="site-nav" aria-label="Navigation principale">
    <a href="#cabinet">Le cabinet</a>
    <a href="#expertises">Expertises</a>
    <a href="#methode">Notre approche</a>
    <a href="#contact" class="nav-cta">Nous contacter</a>
  </nav>
</header>

<main>

  <!-- HERO -->
  <section class="hero" id="accueil">
    <div class="hero__rule" aria-hidden="true"></div>
    <div class="hero__content">
      <p class="eyebrow">Cabinet d'avocats · Paris 8ᵉ · depuis 2005</p>
      <h1>Le droit des affaires,<br>défendu avec rigueur<br>et <em>discrétion</em>.</h1>
      <p class="hero__lead"><?= h($cabinet['baseline']) ?></p>
      <div class="hero__actions">
        <a href="#contact" class="btn btn--gold">Prendre rendez-vous</a>
        <a href="#expertises" class="btn btn--ghost">Découvrir nos expertises</a>
      </div>
    </div>
  </section>

  <!-- CHIFFRES CLÉS -->
  <section class="ledger" aria-label="Le cabinet en chiffres">
    <div class="ledger__item"><span class="ledger__num">2005</span><span class="ledger__lbl">Année de fondation</span></div>
    <div class="ledger__item"><span class="ledger__num">12</span><span class="ledger__lbl">Collaborateurs</span></div>
    <div class="ledger__item"><span class="ledger__num">150<span class="plus">+</span></span><span class="ledger__lbl">Clients accompagnés</span></div>
    <div class="ledger__item"><span class="ledger__num">2,1<span class="plus">M€</span></span><span class="ledger__lbl">de chiffre d'affaires</span></div>
  </section>

  <!-- LE CABINET -->
  <section class="cabinet" id="cabinet">
    <div class="section-head">
      <p class="eyebrow">Le cabinet</p>
      <h2>Une expertise reconnue au service des entreprises</h2>
    </div>
    <div class="cabinet__grid">
      <div class="cabinet__lead">
        <p>Fondé en 2005 par <strong>Maître Richard Dupond</strong>, spécialiste du droit commercial
        et de la compliance, JurisNova réunit douze collaborateurs au cœur du 8ᵉ arrondissement de Paris.</p>
        <p>Nous accompagnons un portefeuille de plus de 150 clients actifs — PME, start-ups et filiales
        de groupes internationaux — sur leurs décisions les plus stratégiques.</p>
      </div>
      <ul class="cabinet__points">
        <li><strong>Confidentialité absolue.</strong> Chaque dossier est couvert par le secret professionnel et protégé par une infrastructure pensée pour la sécurité.</li>
        <li><strong>Conseil et contentieux.</strong> De la prévention du risque juridique à la défense de vos intérêts devant les juridictions.</li>
        <li><strong>Disponibilité.</strong> Un interlocuteur dédié et des réponses dans des délais qui respectent vos contraintes opérationnelles.</li>
      </ul>
    </div>
  </section>

  <!-- EXPERTISES (chargées depuis MariaDB) -->
  <section class="expertises" id="expertises">
    <div class="section-head">
      <p class="eyebrow">Domaines d'intervention</p>
      <h2>Nos expertises</h2>
    </div>
    <div class="expertise-grid">
      <?php foreach ($expertises as $e): ?>
      <article class="expertise-card">
        <h3><?= h($e['titre']) ?></h3>
        <p><?= h($e['resume']) ?></p>
      </article>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- NOTRE APPROCHE -->
  <section class="methode" id="methode">
    <div class="methode__rule" aria-hidden="true"></div>
    <div class="methode__content">
      <p class="eyebrow eyebrow--light">Notre approche</p>
      <h2>La tradition juridique, l'exigence du numérique</h2>
      <p class="methode__lead">Les données que nous traitons — contrats, dossiers contentieux,
      correspondances confidentielles — exigent une rigueur qui ne laisse aucune place à l'approximation.
      Notre cabinet allie le savoir-faire de l'avocat à une infrastructure sécurisée et documentée.</p>
      <div class="methode__cols">
        <div><h3>Écoute</h3><p>Comprendre votre activité et vos enjeux avant de proposer la moindre solution.</p></div>
        <div><h3>Stratégie</h3><p>Construire une réponse juridique claire, justifiée et adaptée à votre réalité.</p></div>
        <div><h3>Protection</h3><p>Garantir la confidentialité de vos informations à chaque étape.</p></div>
      </div>
    </div>
  </section>

  <!-- CONTACT -->
  <section class="contact" id="contact">
    <div class="section-head">
      <p class="eyebrow">Contact</p>
      <h2>Échangeons sur votre dossier</h2>
    </div>

    <div class="contact__grid">
      <div class="contact__info">
        <p class="contact__intro">Premier échange confidentiel et sans engagement. Décrivez-nous votre situation, nous revenons vers vous rapidement.</p>
        <dl class="contact__coords">
          <dt>Adresse</dt>
          <dd><?= h($cabinet['adresse']) ?><br><?= h($cabinet['cp_ville']) ?></dd>
          <dt>Téléphone</dt>
          <dd><a href="tel:<?= h(preg_replace('/[^+0-9]/', '', $cabinet['telephone'])) ?>"><?= h($cabinet['telephone']) ?></a></dd>
          <dt>E-mail</dt>
          <dd><a href="mailto:<?= h($cabinet['email']) ?>"><?= h($cabinet['email']) ?></a></dd>
        </dl>
      </div>

      <div class="contact__form-wrap">
        <?php if ($flash === 'ok'): ?>
          <p class="alert alert--ok" role="status">Merci, votre message a bien été enregistré. Le cabinet vous recontactera sous peu.</p>
        <?php elseif ($flash === 'erreur'): ?>
          <p class="alert alert--err" role="alert">Une erreur technique nous empêche d'enregistrer votre message. Merci de réessayer ou de nous écrire directement par e-mail.</p>
        <?php elseif ($flash === 'invalide'): ?>
          <p class="alert alert--err" role="alert">Certains champs sont manquants ou invalides. Merci de vérifier votre saisie.</p>
        <?php endif; ?>

        <form class="form" action="contact.php" method="post" novalidate>
          <div class="form__row">
            <label>Nom et prénom <span aria-hidden="true">*</span>
              <input type="text" name="nom" required maxlength="120" autocomplete="name">
            </label>
            <label>Organisation
              <input type="text" name="organisation" maxlength="180" autocomplete="organization">
            </label>
          </div>
          <div class="form__row">
            <label>E-mail <span aria-hidden="true">*</span>
              <input type="email" name="email" required maxlength="180" autocomplete="email">
            </label>
            <label>Objet <span aria-hidden="true">*</span>
              <input type="text" name="sujet" required maxlength="160">
            </label>
          </div>
          <label>Votre message <span aria-hidden="true">*</span>
            <textarea name="message" required rows="6" maxlength="4000"></textarea>
          </label>
          <p class="form__legal">Les informations transmises sont traitées de façon strictement confidentielle, conformément au secret professionnel et au RGPD.</p>
          <button type="submit" class="btn btn--gold">Envoyer le message</button>
        </form>
      </div>
    </div>
  </section>

</main>

<footer class="site-footer">
  <div class="footer__top">
    <div class="brand brand--footer">
      <span class="brand__mark" aria-hidden="true">JN</span>
      <span class="brand__text">JurisNova</span>
    </div>
    <p class="footer__base"><?= h($cabinet['baseline']) ?></p>
  </div>
  <div class="footer__bottom">
    <p>© <?= date('Y') ?> Cabinet JurisNova — <?= h($cabinet['adresse']) ?>, <?= h($cabinet['cp_ville']) ?></p>
    <p><a href="mentions-legales.php">Mentions légales</a></p>
  </div>
</footer>

</body>
</html>
