# Site vitrine — Cabinet JurisNova

Site vitrine PHP du cabinet, à héberger sur le serveur **Apache (VLAN 20 / DMZ_Web, 10.0.0.130)**.
Lecture des expertises et enregistrement des messages de contact via **MariaDB (VLAN 30 / DMZ_BDD, 10.0.0.162)**.

## Contenu

| Fichier | Rôle |
|---|---|
| `index.php` | Page principale (accueil, cabinet, expertises, approche, contact) |
| `contact.php` | Traitement du formulaire (INSERT préparé dans MariaDB) |
| `mentions-legales.php` | Mentions légales |
| `config.php` | Paramètres BDD + coordonnées du cabinet |
| `db.php` | Connexion mysqli à MariaDB |
| `schema.sql` | Création de la base `jurisnova_db` + données des expertises |
| `assets/style.css` | Charte graphique (bleu marine + or) |

## Déploiement (rappel, cohérent avec votre rapport § 5.1 et Étape 4)

1. **Base de données** — sur le serveur MariaDB (10.0.0.162), en root :
   ```bash
   mysql < schema.sql
   ```
   Le compte applicatif `user_web` (droits `SELECT` + `INSERT` déjà accordés dans votre rapport)
   suffit ensuite : lecture des expertises et insertion des messages de contact.

2. **Site** — copier le dossier dans la racine Apache du VirtualHost du site vitrine :
   ```bash
   sudo cp -r jurisnova/* /var/www/html/
   sudo chown -R www-data:www-data /var/www/html/
   ```

3. **Vérifier** — depuis un poste du LAN (VLAN 10), ouvrir `http://10.0.0.130`.
   - Les 6 expertises s'affichent → **lecture MariaDB OK** (test « Connexion BDD OK » de la soutenance).
   - Envoyer un message via le formulaire → une ligne apparaît dans `messages_contact` → **écriture MariaDB OK**.

## À personnaliser avant la soutenance

- `config.php` : adresse exacte du cabinet, téléphone, e-mail, et **mot de passe MariaDB**
  (mettez la vraie valeur de votre `CREATE USER ... IDENTIFIED BY '...'`).
- En production, remplacer le certificat auto-signé par un certificat reconnu (Let's Encrypt),
  comme indiqué dans votre rapport § 5.1.

## Notes sécurité (déjà alignées sur votre cahier des charges)

- Requêtes **préparées** côté contact → pas d'injection SQL.
- Échappement systématique des sorties (`htmlspecialchars`) → pas de XSS.
- Le site reste consultable même si MariaDB est momentanément injoignable (repli statique).
- Les erreurs BDD sont écrites dans les logs serveur, jamais affichées au visiteur
  (cohérent avec la journalisation Apache `access.log` / `error.log` de votre rapport § 6.3).
